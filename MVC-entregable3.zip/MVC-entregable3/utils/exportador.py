# en este archivo estan todas las funciones de exportacion
import openpyxl
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

class Exportador:
    @staticmethod
    def exportar_excel(datos, nombre_archivo, encabezados):
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Datos"

            ws.append(encabezados)

            for dato in datos:
                ws.append(list(dato.values())) # Convertir dict a lista para append

            wb.save(nombre_archivo)
            return True, f"Archivo {nombre_archivo} guardado exitosamente"
        except Exception as e:
            return False, f"Error exportando a Excel: {e}"

    @staticmethod
    def exportar_pdf(datos, nombre_archivo, titulo, encabezados):
        try:
            c = canvas.Canvas(nombre_archivo, pagesize=letter)
            width, height = letter

            c.setFont("Helvetica-Bold", 16)
            c.drawString(100, height - 50, titulo)

            c.setFont("Helvetica-Bold", 8)
            y = height - 100
            x_positions = [50, 100, 180, 280, 360, 440, 520]

            for i, encabezado in enumerate(encabezados):
                if i < len(x_positions):
                    c.drawString(x_positions[i], y, str(encabezado))

            c.setFont("Helvetica", 8)
            y -= 20

            for fila_dict in datos:
                fila = list(fila_dict.values())
                if y < 80:
                    c.showPage()
                    y = height - 100

                for i, valor in enumerate(fila):
                    if i < len(x_positions):
                        texto = str(valor)[:25] + "..." if len(str(valor)) > 25 else str(valor)
                        c.drawString(x_positions[i], y, texto)
                y -= 15

            c.save()
            return True, f"Archivo {nombre_archivo} generado exitosamente"
        except Exception as e:
            return False, f"Error generando PDF: {e}"
