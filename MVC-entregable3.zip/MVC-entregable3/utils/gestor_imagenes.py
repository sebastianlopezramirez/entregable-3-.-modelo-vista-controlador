#en este modulo esta las funciones de gestor de imagenes

from tkinter import filedialog, messagebox
from PIL import Image, ImageTk, ImageFilter
from .validaciones import Validaciones # Importación local

class GestorImagenes:
    def __init__(self):
        self.imagen_tk = None
        self.ruta_imagen_actual = None

    def cargar_imagen(self, label_imagen, ancho=150, alto=150):
        self.ruta_imagen_actual = None
        ruta = filedialog.askopenfilename(
            title="Seleccionar imagen",
            filetypes=[("Imágenes", "*.jpg *.jpeg *.png *.gif")]
        )

        if ruta:
            valido, mensaje = Validaciones.validar_imagen(ruta)
            if not valido:
                messagebox.showerror("Error de Imagen", mensaje)
                return

            try:
                imagen = Image.open(ruta)
                imagen.thumbnail((ancho, alto), Image.Resampling.LANCZOS)
                self.imagen_tk = ImageTk.PhotoImage(imagen)
                label_imagen.config(image=self.imagen_tk)
                self.ruta_imagen_actual = ruta
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo cargar la imagen: {e}")

    def aplicar_filtro(self, filtro, label_imagen, ancho=150, alto=150):
        if not self.ruta_imagen_actual:
            messagebox.showwarning("Advertencia", "Primero carga una imagen.")
            return

        try:
            imagen = Image.open(self.ruta_imagen_actual)
            if filtro == "escala_grises":
                imagen = imagen.convert("L")
            elif filtro == "desenfoque":
                imagen = imagen.filter(ImageFilter.BLUR)
            elif filtro == "nitidez":
                imagen = imagen.filter(ImageFilter.SHARPEN)

            imagen.thumbnail((ancho, alto), Image.Resampling.LANCZOS)
            self.imagen_tk = ImageTk.PhotoImage(imagen)
            label_imagen.config(image=self.imagen_tk)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo aplicar filtro: {e}")
