# en este archivo.py estan las funciones de configuracion y tema del proyecto

class Configuracion:
    def __init__(self):
        self.tema_actual = "claro"
        self.temas = {
            "claro": {
                "bg": "#F0F0F0", "fg": "black", "button_bg": "#D0D0D0",
                "title_bg": "#1A5276", "title_fg": "white",
                "entry_bg": "white", "entry_fg": "black", "tree_bg": "white",
                "tree_fg": "black", "tree_heading": "#E0E0E0"
            },
            "oscuro": {
                "bg": "#2E2E2E", "fg": "white", "button_bg": "#5D5D5D",
                "title_bg": "#154360", "title_fg": "white",
                "entry_bg": "#404040", "entry_fg": "white", "tree_bg": "#333333",
                "tree_fg": "white", "tree_heading": "#444444"
            }
        }

    def cambiar_tema(self, tema):
        if tema in self.temas:
            self.tema_actual = tema
            return self.temas[tema]
        return self.temas["claro"]