# en este archivo estaran todas las validaciones
import re
import os


class Validaciones:
    @staticmethod
    def validar_numerico(valor):
        if valor == "": return True
        return valor.isdigit()

    @staticmethod
    def validar_decimal(valor):
        try:
            if valor == "": return True
            float(valor)
            return True
        except ValueError:
            return False

    @staticmethod
    def validar_email(email):
        if email == "": return True
        patron = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(patron, email) is not None

    @staticmethod
    def validar_longitud(texto, min_len=1, max_len=100):
        return min_len <= len(texto) <= max_len

    @staticmethod
    def validar_imagen(ruta_imagen, max_size_mb=5):
        if not ruta_imagen:
            return True, "OK"

        formatos_permitidos = ['.jpg', '.jpeg', '.png', '.gif']
        extension = os.path.splitext(ruta_imagen)[1].lower()

        if extension not in formatos_permitidos:
            return False, "Formato no permitido. Use JPG, PNG o GIF"

        if os.path.getsize(ruta_imagen) > max_size_mb * 1024 * 1024:
            return False, f"Imagen muy grande (máximo {max_size_mb}MB)"

        return True, "OK"
