# views/main_view.py
import tkinter as tk
from tkinter import ttk
from views.cliente_view import ClienteView
# --- IMPORTAR NUEVAS VISTAS ---
from views.producto_view import ProductoView
from views.categoria_view import CategoriaView
from views.empleado_view import EmpleadoView

class MainView(tk.Tk):
    def __init__(self, config):
        super().__init__()
        self.title("Sistema Comercial - Gestión Integral")
        self.geometry("1200x800")
        self._config = config

        try:
            self.iconbitmap("assets/favicon.ico")
        except tk.TclError:
            print("No se encontró favicon.ico.")

        self.style = ttk.Style()
        self.style.theme_use('clam')

        self._setup_menu()
        self._setup_notebook()
        self.aplicar_tema_a_todo("claro")

    def _setup_menu(self):
        self.menu_bar = tk.Menu(self)
        self.config(menu=self.menu_bar)
        self.tema_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Tema", menu=self.tema_menu)
        self.tema_menu.add_command(label="Claro", command=lambda: self.aplicar_tema_a_todo("claro"))
        self.tema_menu.add_command(label="Oscuro", command=lambda: self.aplicar_tema_a_todo("oscuro"))

    def _setup_notebook(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)

        # Aquí creamos las pestañas
        self.cliente_tab = ClienteView(self.notebook)
        # --- CREAR INSTANCIAS DE LAS NUEVAS VISTAS ---
        self.producto_tab = ProductoView(self.notebook)
        self.categoria_tab = CategoriaView(self.notebook)
        self.empleado_tab = EmpleadoView(self.notebook)

        self.notebook.add(self.cliente_tab, text="Clientes")
        # --- AÑADIR LAS NUEVAS PESTAÑAS AL NOTEBOOK ---
        self.notebook.add(self.producto_tab, text="Productos")
        self.notebook.add(self.categoria_tab, text="Categorías")
        self.notebook.add(self.empleado_tab, text="Empleados")


    def aplicar_tema_a_todo(self, nombre_tema):
        colores = self._config.cambiar_tema(nombre_tema)
        self.config(bg=colores["bg"])
        # (Este método es largo, asegúrate de que esté completo en tu archivo original)
        # Aquí iría el código para aplicar estilos a todos los widgets.
        # Por ejemplo:
        self.style.configure('TFrame', background=colores['bg'])
        self.style.configure('TLabel', background=colores['bg'], foreground=colores['fg'])
        self.style.configure('Title.TLabel', background=colores['title_bg'], foreground=colores['title_fg'], font=("Arial", 14, "bold"))
        self.style.configure('Header.TLabel', background=colores['bg'], foreground=colores['fg'], font=("Arial", 10, "bold"))
        self.style.configure('TButton', background=colores['button_bg'], foreground=colores['fg'])
        self.style.map('TButton', background=[('active', colores['fg'])])
        self.style.configure('TEntry', fieldbackground=colores['entry_bg'], foreground=colores['entry_fg'])
        self.style.configure('Treeview', background=colores['tree_bg'], fieldbackground=colores['tree_bg'], foreground=colores['tree_fg'])
        self.style.configure('Treeview.Heading', background=colores['tree_heading'], foreground=colores['fg'])
        self.style.map('Treeview.Heading', background=[('active', colores['title_bg'])])
        self.style.configure('TNotebook', background=colores['bg'])
        self.style.configure('TNotebook.Tab', background=colores['bg'], foreground=colores['fg'])
        self.style.map('TNotebook.Tab', background=[("selected", colores['title_bg'])], foreground=[("selected", colores['title_fg'])])


    def main(self):
        self.mainloop()