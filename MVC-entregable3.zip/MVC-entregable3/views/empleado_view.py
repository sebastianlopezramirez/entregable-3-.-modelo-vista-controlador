# views/empleado_view.py
import tkinter as tk
from tkinter import ttk

class EmpleadoView(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)

        form_container, table_container = self._crear_layout_base()
        self.entries = self._crear_formulario(form_container)
        self._crear_botones_crud(form_container)
        self.tree = self._crear_tabla(table_container)
        self._crear_botones_exportacion(table_container)

    def _crear_layout_base(self):
        ttk.Label(self, text="GESTIÓN DE EMPLEADOS", style='Title.TLabel').pack(pady=10, fill="x")
        main_frame = ttk.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)
        form_container = ttk.Frame(main_frame, width=350)
        form_container.pack(side="left", fill="y", padx=(0, 20), anchor='n')
        table_container = ttk.Frame(main_frame)
        table_container.pack(side="right", fill="both", expand=True)
        return form_container, table_container

    def _crear_formulario(self, parent):
        campos = [
            ("ID:", "id"), ("Nombre:", "nombre"), ("Apellido:", "apellido"),
            ("Email:", "email"), ("Teléfono:", "telefono"), ("Cargo:", "cargo"),
            ("Departamento:", "departamento"), ("Contratación (YYYY-MM-DD):", "fecha_contratacion"),
            ("Salario:", "salario")
        ]
        entries = {}
        for i, (texto, nombre) in enumerate(campos):
            ttk.Label(parent, text=texto, style='Header.TLabel').grid(row=i, column=0, sticky="w", padx=(0, 10), pady=5)
            entry = ttk.Entry(parent, width=30, font=("Arial", 10))
            entry.grid(row=i, column=1, sticky="w", pady=5)
            entries[nombre] = entry

        entries['id'].config(state='readonly')
        return entries

    def _crear_tabla(self, parent):
        columnas = {
            "id": "ID", "nombre": "Nombre", "apellido": "Apellido", "email": "Email",
            "cargo": "Cargo", "departamento": "Departamento"
        }
        anchos = {
            "id": 40, "nombre": 120, "apellido": 120, "email": 180,
            "cargo": 120, "departamento": 120
        }

        tree = ttk.Treeview(parent, columns=list(columnas.keys()), show='headings')
        for col, nombre in columnas.items():
            tree.heading(col, text=nombre)
            tree.column(col, width=anchos.get(col, 100), anchor='w')

        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        return tree

    def _crear_botones_crud(self, parent):
        btn_frame = ttk.Frame(parent)
        btn_frame.grid(row=100, column=0, columnspan=2, pady=20)
        self.btn_guardar = ttk.Button(btn_frame, text="Guardar")
        self.btn_actualizar = ttk.Button(btn_frame, text="Actualizar")
        self.btn_eliminar = ttk.Button(btn_frame, text="Eliminar")
        self.btn_limpiar = ttk.Button(btn_frame, text="Limpiar")
        # Packs...
        self.btn_guardar.pack(side=tk.LEFT, padx=5)
        self.btn_actualizar.pack(side=tk.LEFT, padx=5)
        self.btn_eliminar.pack(side=tk.LEFT, padx=5)
        self.btn_limpiar.pack(side=tk.LEFT, padx=5)

    def _crear_botones_exportacion(self, parent):
        export_frame = ttk.Frame(parent)
        export_frame.pack(pady=10, fill='x')
        self.btn_excel = ttk.Button(export_frame, text="Excel")
        self.btn_pdf = ttk.Button(export_frame, text="PDF")
        ttk.Label(export_frame, text="Exportar:").pack(side=tk.LEFT, padx=5)
        self.btn_excel.pack(side=tk.LEFT, padx=5)
        self.btn_pdf.pack(side=tk.LEFT, padx=5)

    def obtener_datos_formulario(self):
        return {key: entry.get() for key, entry in self.entries.items()}

    def llenar_formulario(self, datos):
        self.limpiar_formulario()
        for key, entry in self.entries.items():
            if key in datos and datos[key] is not None:
                entry.config(state='normal')
                entry.insert(0, str(datos[key]))
        self.entries['id'].config(state='readonly')

    def limpiar_formulario(self):
        for entry in self.entries.values():
            entry.config(state='normal')
            entry.delete(0, tk.END)
        self.entries['id'].config(state='readonly')

    def actualizar_tabla(self, datos):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for fila in datos:
            valores = (
                fila['id'], fila['nombre'], fila['apellido'], fila['email'],
                fila['cargo'], fila['departamento']
            )
            self.tree.insert("", "end", values=valores)