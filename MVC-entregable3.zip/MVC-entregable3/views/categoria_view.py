# views/categoria_view.py
import tkinter as tk
from tkinter import ttk

class CategoriaView(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)

        form_container, table_container = self._crear_layout_base()
        self.entries, self.label_imagen = self._crear_formulario(form_container)
        self._crear_botones_crud(form_container)
        self.tree = self._crear_tabla(table_container)
        self._crear_botones_exportacion(table_container)

    def _crear_layout_base(self):
        ttk.Label(self, text="GESTIÓN DE CATEGORÍAS", style='Title.TLabel').pack(pady=10, fill="x")
        main_frame = ttk.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)
        form_container = ttk.Frame(main_frame, width=350)
        form_container.pack(side="left", fill="y", padx=(0, 20), anchor='n')
        table_container = ttk.Frame(main_frame)
        table_container.pack(side="right", fill="both", expand=True)
        return form_container, table_container

    def _crear_formulario(self, parent):
        campos = [("ID:", "id"), ("Nombre:", "nombre"), ("Descripción:", "descripcion")]
        entries = {}
        for i, (texto, nombre) in enumerate(campos):
            ttk.Label(parent, text=texto, style='Header.TLabel').grid(row=i, column=0, sticky="w", padx=(0, 10), pady=5)
            if nombre == "descripcion":
                entry = tk.Text(parent, width=30, height=4, font=("Arial", 10))
            else:
                entry = ttk.Entry(parent, width=30, font=("Arial", 10))
            entry.grid(row=i, column=1, sticky="w", pady=5)
            entries[nombre] = entry

        entries['id'].config(state='readonly')

        # Widget para la imagen
        ttk.Label(parent, text="Imagen:", style='Header.TLabel').grid(row=len(campos), column=0, sticky="nw", padx=(0, 10), pady=5)
        img_frame = ttk.Frame(parent)
        img_frame.grid(row=len(campos), column=1, sticky="w", pady=5)

        # --- LÍNEA CORREGIDA ---
        label_imagen = ttk.Label(img_frame, text="Sin imagen", relief="solid", width=20, anchor="center")

        label_imagen.pack(side="left")
        self.btn_cargar_img = ttk.Button(img_frame, text="Cargar")
        self.btn_cargar_img.pack(side="left", padx=5)
        entries['imagen'] = ""

        return entries, label_imagen

    def _crear_tabla(self, parent):
        columnas = {"id": "ID", "nombre": "Nombre", "descripcion": "Descripción"}
        anchos = {"id": 40, "nombre": 200, "descripcion": 400}

        tree = ttk.Treeview(parent, columns=list(columnas.keys()), show='headings')
        for col, nombre in columnas.items():
            tree.heading(col, text=nombre)
            tree.column(col, width=anchos.get(col, 100), anchor='w')

        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        return tree

    def _crear_botones_crud(self, parent):
        btn_frame = ttk.Frame(parent)
        btn_frame.grid(row=100, column=0, columnspan=2, pady=20)
        self.btn_guardar = ttk.Button(btn_frame, text="Guardar")
        self.btn_actualizar = ttk.Button(btn_frame, text="Actualizar")
        self.btn_eliminar = ttk.Button(btn_frame, text="Eliminar")
        self.btn_limpiar = ttk.Button(btn_frame, text="Limpiar")
        self.btn_guardar.pack(side=tk.LEFT, padx=5)
        self.btn_actualizar.pack(side=tk.LEFT, padx=5)
        self.btn_eliminar.pack(side=tk.LEFT, padx=5)
        self.btn_limpiar.pack(side=tk.LEFT, padx=5)


    def _crear_botones_exportacion(self, parent):
        export_frame = ttk.Frame(parent)
        export_frame.pack(pady=10, fill='x')
        self.btn_excel = ttk.Button(export_frame, text="Excel")
        self.btn_pdf = ttk.Button(export_frame, text="PDF")
        ttk.Label(export_frame, text="Exportar:").pack(side=tk.LEFT, padx=5)
        self.btn_excel.pack(side=tk.LEFT, padx=5)
        self.btn_pdf.pack(side=tk.LEFT, padx=5)

    def obtener_datos_formulario(self):
        datos = {}
        for key, widget in self.entries.items():
            if isinstance(widget, tk.Text):
                datos[key] = widget.get("1.0", tk.END).strip()
            elif key != 'imagen':
                datos[key] = widget.get()
        return datos

    def llenar_formulario(self, datos):
        self.limpiar_formulario()
        for key, widget in self.entries.items():
            if key in datos and datos[key] is not None:
                widget.config(state='normal')
                if isinstance(widget, tk.Text):
                    widget.insert("1.0", str(datos[key]))
                elif key != 'imagen':
                    widget.insert(0, str(datos[key]))
        self.entries['id'].config(state='readonly')

    def limpiar_formulario(self):
        for key, widget in self.entries.items():
            widget.config(state='normal')
            if isinstance(widget, tk.Text):
                widget.delete("1.0", tk.END)
            elif key != 'imagen':
                widget.delete(0, tk.END)
        self.entries['id'].config(state='readonly')
        self.label_imagen.config(image=None, text="Sin imagen")


    def actualizar_tabla(self, datos):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for fila in datos:
            valores = (fila['id'], fila['nombre'], fila['descripcion'])
            self.tree.insert("", "end", values=valores)