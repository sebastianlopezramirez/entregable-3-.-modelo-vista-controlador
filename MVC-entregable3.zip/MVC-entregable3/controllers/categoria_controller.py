# controllers/categoria_controller.py
from tkinter import messagebox
from utils.validaciones import Validaciones
from utils.gestor_imagenes import GestorImagenes

class CategoriaController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.v = Validaciones()
        self.img_manager = GestorImagenes()
        self._asignar_comandos()
        self.actualizar_vista_categorias()

    def _asignar_comandos(self):
        self.view.btn_guardar.config(command=self.guardar_categoria)
        self.view.btn_actualizar.config(command=self.actualizar_categoria)
        self.view.btn_eliminar.config(command=self.eliminar_categoria)
        self.view.btn_limpiar.config(command=self.view.limpiar_formulario)
        self.view.btn_cargar_img.config(command=self.cargar_imagen_categoria)
        self.view.tree.bind('<<TreeviewSelect>>', self.seleccionar_categoria)

    def actualizar_vista_categorias(self):
        categorias = self.model.obtener_categorias()
        self.view.actualizar_tabla(categorias)

    def cargar_imagen_categoria(self):
        self.img_manager.cargar_imagen(self.view.label_imagen)

    def guardar_categoria(self):
        datos = self.view.obtener_datos_formulario()
        if not self.v.validar_longitud(datos['nombre'], 2):
            messagebox.showerror("Error", "El nombre es muy corto.")
            return

        if not messagebox.askyesno("Confirmar", "¿Guardar nueva categoría?"): return

        args = [
            datos['nombre'], datos['descripcion'],
            self.img_manager.ruta_imagen_actual or ''
        ]

        if self.model.insertar_categoria(args):
            messagebox.showinfo("Éxito", "Categoría guardada.")
            self.actualizar_vista_categorias()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo guardar la categoría.")

    def actualizar_categoria(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione una categoría.")
            return

        if not messagebox.askyesno("Confirmar", "¿Actualizar esta categoría?"): return

        args = [
            datos['id'], datos['nombre'], datos['descripcion'],
            self.img_manager.ruta_imagen_actual or ''
        ]

        if self.model.actualizar_categoria(args):
            messagebox.showinfo("Éxito", "Categoría actualizada.")
            self.actualizar_vista_categorias()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo actualizar.")

    def eliminar_categoria(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione una categoría.")
            return

        if not messagebox.askyesno("Confirmar", "¿Eliminar categoría?"): return

        if self.model.eliminar_categoria(datos['id']):
            messagebox.showinfo("Éxito", "Categoría eliminada.")
            self.actualizar_vista_categorias()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo eliminar.")

    def seleccionar_categoria(self, event):
        selected_item = self.view.tree.selection()
        if not selected_item: return

        item_values = self.view.tree.item(selected_item[0], 'values')
        # Crear un diccionario con los datos de la fila seleccionada
        categoria_seleccionada = {
            'id': item_values[0],
            'nombre': item_values[1],
            'descripcion': item_values[2]
            # La imagen no se muestra en la tabla, se podría cargar si se guardara la ruta
        }
        self.view.llenar_formulario(categoria_seleccionada)