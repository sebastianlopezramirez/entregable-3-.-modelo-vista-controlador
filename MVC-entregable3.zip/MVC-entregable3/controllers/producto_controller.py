# controllers/producto_controller.py
from tkinter import messagebox
from utils.validaciones import Validaciones
from utils.gestor_imagenes import GestorImagenes

class ProductoController:
    def __init__(self, model, categoria_model, view):
        self.model = model
        self.categoria_model = categoria_model
        self.view = view
        self.v = Validaciones()
        self.img_manager = GestorImagenes()
        self.categorias = [] # Cache para los nombres y IDs de categorías
        self._asignar_comandos()
        self.actualizar_vista_productos()
        self.cargar_categorias()

    def _asignar_comandos(self):
        self.view.btn_guardar.config(command=self.guardar_producto)
        self.view.btn_actualizar.config(command=self.actualizar_producto)
        self.view.btn_eliminar.config(command=self.eliminar_producto)
        self.view.btn_limpiar.config(command=self.view.limpiar_formulario)
        self.view.btn_cargar_img.config(command=self.cargar_imagen_producto)
        self.view.tree.bind('<<TreeviewSelect>>', self.seleccionar_producto)

    def actualizar_vista_productos(self):
        productos = self.model.obtener_productos()
        self.view.actualizar_tabla(productos)

    def cargar_categorias(self):
        self.categorias = self.categoria_model.obtener_categorias()
        self.view.actualizar_categorias_dropdown(self.categorias)

    def cargar_imagen_producto(self):
        self.img_manager.cargar_imagen(self.view.label_imagen)

    def _obtener_id_categoria_seleccionada(self):
        nombre_cat = self.view.combo_categoria.get()
        for cat in self.categorias:
            if cat['nombre'] == nombre_cat:
                return cat['id']
        return None

    def guardar_producto(self):
        datos = self.view.obtener_datos_formulario()
        categoria_id = self._obtener_id_categoria_seleccionada()

        if not all([datos['nombre'], datos['precio'], datos['stock'], categoria_id]):
            messagebox.showerror("Error", "Nombre, precio, stock y categoría son obligatorios.")
            return
        if not self.v.validar_decimal(datos['precio']) or not self.v.validar_numerico(datos['stock']):
            messagebox.showerror("Error", "Precio y stock deben ser numéricos.")
            return

        if not messagebox.askyesno("Confirmar", "¿Guardar nuevo producto?"): return

        args = [
            categoria_id, datos['nombre'], datos['descripcion'],
            datos['precio'], datos['stock'], datos['codigo_sku'],
            self.img_manager.ruta_imagen_actual or ''
        ]

        if self.model.insertar_producto(args):
            messagebox.showinfo("Éxito", "Producto guardado.")
            self.actualizar_vista_productos()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo guardar el producto.")

    def actualizar_producto(self):
        datos = self.view.obtener_datos_formulario()
        categoria_id = self._obtener_id_categoria_seleccionada()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione un producto.")
            return

        if not messagebox.askyesno("Confirmar", "¿Actualizar producto?"): return

        args = [
            datos['id'], categoria_id, datos['nombre'], datos['descripcion'],
            datos['precio'], datos['stock'], datos['codigo_sku'],
            self.img_manager.ruta_imagen_actual or ''
        ]

        if self.model.actualizar_producto(args):
            messagebox.showinfo("Éxito", "Producto actualizado.")
            self.actualizar_vista_productos()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo actualizar.")

    def eliminar_producto(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione un producto.")
            return

        if not messagebox.askyesno("Confirmar", "¿Eliminar producto?"): return

        if self.model.eliminar_producto(datos['id']):
            messagebox.showinfo("Éxito", "Producto eliminado.")
            self.actualizar_vista_productos()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo eliminar.")

    def seleccionar_producto(self, event):
        selected_item = self.view.tree.selection()
        if not selected_item: return

        # Para obtener todos los datos del producto, es mejor hacer una consulta por ID
        item_id = self.view.tree.item(selected_item[0], 'values')[0]
        # Necesitaríamos un método `obtener_producto_por_id` en el modelo
        # Por ahora, simulamos con los datos de la tabla.
        item_values = self.view.tree.item(selected_item[0], 'values')
        # Buscamos el producto completo para obtener el ID de la categoría
        producto_completo = next((p for p in self.model.obtener_productos() if p['id'] == int(item_id)), None)

        if producto_completo:
            self.view.llenar_formulario(producto_completo, self.categorias)