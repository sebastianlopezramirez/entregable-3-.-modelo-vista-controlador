# este archivo recibe el modleo y la vista y los coloca a trabajar juntos

# controllers/cliente_controller.py
from tkinter import messagebox
from utils.validaciones import Validaciones

class ClienteController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.v = Validaciones() # Instancia de validaciones
        self._asignar_comandos()
        self.actualizar_vista_clientes()

    def _asignar_comandos(self):
        # Asignar funciones a los botones de la vista
        self.view.btn_guardar.config(command=self.guardar_cliente)
        self.view.btn_actualizar.config(command=self.actualizar_cliente)
        self.view.btn_eliminar.config(command=self.eliminar_cliente)
        self.view.btn_limpiar.config(command=self.view.limpiar_formulario)

        # Asignar evento de selección a la tabla
        self.view.tree.bind('<<TreeviewSelect>>', self.seleccionar_cliente)

        # Faltarían los comandos para exportar, se añaden de forma similar

    def actualizar_vista_clientes(self):
        clientes = self.model.obtener_clientes()
        self.view.actualizar_tabla(clientes)

    def guardar_cliente(self):
        datos = self.view.obtener_datos_formulario()

        # Validaciones
        if not self.v.validar_longitud(datos['nombre'], 2):
            messagebox.showerror("Error", "El nombre es muy corto.")
            return
        if not self.v.validar_email(datos['email']):
            messagebox.showerror("Error", "Email inválido.")
            return

        if not messagebox.askyesno("Confirmar", "¿Guardar nuevo cliente?"): return

        args = [
            datos['nombre'], datos['apellido'], datos['email'],
            datos['telefono'], datos['direccion'], datos['ciudad'],
            datos['codigo_postal'], datos['pais']
        ]

        if self.model.insertar_cliente(args):
            messagebox.showinfo("Éxito", "Cliente guardado correctamente.")
            self.actualizar_vista_clientes()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo guardar el cliente.")

    def actualizar_cliente(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione un cliente de la tabla.")
            return

        if not messagebox.askyesno("Confirmar", "¿Actualizar este cliente?"): return

        args = [
            datos['id'], datos['nombre'], datos['apellido'], datos['email'],
            datos['telefono'], datos['direccion'], datos['ciudad'],
            datos['codigo_postal'], datos['pais']
        ]

        if self.model.actualizar_cliente(args):
            messagebox.showinfo("Éxito", "Cliente actualizado correctamente.")
            self.actualizar_vista_clientes()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo actualizar el cliente.")

    def eliminar_cliente(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione un cliente para eliminar.")
            return

        if not messagebox.askyesno("Confirmar", "¿Está seguro? Esta acción no se puede deshacer."): return

        if self.model.eliminar_cliente(datos['id']):
            messagebox.showinfo("Éxito", "Cliente eliminado.")
            self.actualizar_vista_clientes()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo eliminar el cliente.")

    def seleccionar_cliente(self, event):
        selected_item = self.view.tree.selection()
        if not selected_item: return

        item_id = self.view.tree.item(selected_item[0], 'values')[0]
        cliente_completo = self.model.obtener_cliente_por_id(item_id)

        if cliente_completo:
            self.view.llenar_formulario(cliente_completo)