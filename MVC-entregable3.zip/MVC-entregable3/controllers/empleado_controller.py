# controllers/empleado_controller.py
from tkinter import messagebox
from utils.validaciones import Validaciones

class EmpleadoController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.v = Validaciones()
        self._asignar_comandos()
        self.actualizar_vista_empleados()

    def _asignar_comandos(self):
        self.view.btn_guardar.config(command=self.guardar_empleado)
        self.view.btn_actualizar.config(command=self.actualizar_empleado)
        self.view.btn_eliminar.config(command=self.eliminar_empleado)
        self.view.btn_limpiar.config(command=self.view.limpiar_formulario)
        self.view.tree.bind('<<TreeviewSelect>>', self.seleccionar_empleado)

    def actualizar_vista_empleados(self):
        empleados = self.model.obtener_empleados()
        self.view.actualizar_tabla(empleados)

    def guardar_empleado(self):
        datos = self.view.obtener_datos_formulario()

        if not all([datos['nombre'], datos['apellido'], datos['email'], datos['cargo']]):
            messagebox.showerror("Error", "Nombre, apellido, email y cargo son obligatorios.")
            return
        if not self.v.validar_email(datos['email']):
            messagebox.showerror("Error", "Email inválido.")
            return

        if not messagebox.askyesno("Confirmar", "¿Guardar nuevo empleado?"): return

        args = [
            datos['nombre'], datos['apellido'], datos['email'], datos['telefono'],
            datos['cargo'], datos['departamento'], datos['fecha_contratacion'] or None,
            datos['salario'] or 0
        ]

        if self.model.insertar_empleado(args):
            messagebox.showinfo("Éxito", "Empleado guardado.")
            self.actualizar_vista_empleados()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo guardar el empleado.")

    def actualizar_empleado(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione un empleado.")
            return

        if not messagebox.askyesno("Confirmar", "¿Actualizar empleado?"): return

        args = [
            datos['id'], datos['nombre'], datos['apellido'], datos['email'], datos['telefono'],
            datos['cargo'], datos['departamento'], datos['fecha_contratacion'] or None,
            datos['salario'] or 0
        ]

        if self.model.actualizar_empleado(args):
            messagebox.showinfo("Éxito", "Empleado actualizado.")
            self.actualizar_vista_empleados()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo actualizar.")

    def eliminar_empleado(self):
        datos = self.view.obtener_datos_formulario()
        if not datos['id']:
            messagebox.showerror("Error", "Seleccione un empleado.")
            return

        if not messagebox.askyesno("Confirmar", "¿Eliminar empleado?"): return

        if self.model.eliminar_empleado(datos['id']):
            messagebox.showinfo("Éxito", "Empleado eliminado.")
            self.actualizar_vista_empleados()
            self.view.limpiar_formulario()
        else:
            messagebox.showerror("Error", "No se pudo eliminar.")

    def seleccionar_empleado(self, event):
        selected_item = self.view.tree.selection()
        if not selected_item: return

        # Necesitaríamos un 'obtener_empleado_por_id' para tener todos los datos.
        # Por ahora, simulamos con una búsqueda en la lista completa.
        item_id = self.view.tree.item(selected_item[0], 'values')[0]
        empleados = self.model.obtener_empleados()
        empleado_completo = next((e for e in empleados if e['id'] == int(item_id)), None)

        if empleado_completo:
            self.view.llenar_formulario(empleado_completo)