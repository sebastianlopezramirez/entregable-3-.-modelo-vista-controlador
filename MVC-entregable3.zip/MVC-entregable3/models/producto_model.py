# models/producto Para operaciones CRUD
from mysql.connector import Error

class ProductoModel:
    def __init__(self, conexion):
        self.conexion = conexion

    def obtener_productos(self):
        if self.conexion is None: return []
        try:
            cursor = self.conexion.cursor(dictionary=True)
            cursor.callproc('ObtenerProductos')
            productos = []
            for result in cursor.stored_results():
                productos = result.fetchall()
            cursor.close()
            return productos
        except Error as e:
            print(f"Error al obtener productos: {e}")
            return []

    def insertar_producto(self, datos_producto):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('InsertarProducto', datos_producto)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al insertar producto: {e}")
            return False

    def actualizar_producto(self, datos_producto):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('ActualizarProducto', datos_producto)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al actualizar producto: {e}")
            return False

    def eliminar_producto(self, id_producto):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('EliminarProducto', [id_producto])
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al eliminar producto: {e}")
            return False