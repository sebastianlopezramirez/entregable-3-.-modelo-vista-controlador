# models/categoria PARA OPERACIONES crud
from mysql.connector import Error

class CategoriaModel:
    def __init__(self, conexion):
        self.conexion = conexion

    def obtener_categorias(self):
        if self.conexion is None: return []
        try:
            cursor = self.conexion.cursor(dictionary=True)
            cursor.callproc('ObtenerCategorias')
            categorias = []
            for result in cursor.stored_results():
                categorias = result.fetchall()
            cursor.close()
            return categorias
        except Error as e:
            print(f"Error al obtener categorías: {e}")
            return []

    def insertar_categoria(self, datos_categoria):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('InsertarCategoria', datos_categoria)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al insertar categoría: {e}")
            return False

    def actualizar_categoria(self, datos_categoria):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('ActualizarCategoria', datos_categoria)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al actualizar categoría: {e}")
            return False

    def eliminar_categoria(self, id_categoria):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('EliminarCategoria', [id_categoria])
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al eliminar categoría: {e}")
            return False