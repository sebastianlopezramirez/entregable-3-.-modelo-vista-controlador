# models/empleado para operaciones CRUD
from mysql.connector import Error

class EmpleadoModel:
    def __init__(self, conexion):
        self.conexion = conexion

    def obtener_empleados(self):
        if self.conexion is None: return []
        try:
            cursor = self.conexion.cursor(dictionary=True)
            cursor.callproc('ObtenerEmpleados')
            empleados = []
            for result in cursor.stored_results():
                empleados = result.fetchall()
            cursor.close()
            return empleados
        except Error as e:
            print(f"Error al obtener empleados: {e}")
            return []

    def insertar_empleado(self, datos_empleado):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('InsertarEmpleado', datos_empleado)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al insertar empleado: {e}")
            return False

    def actualizar_empleado(self, datos_empleado):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('ActualizarEmpleado', datos_empleado)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al actualizar empleado: {e}")
            return False

    def eliminar_empleado(self, id_empleado):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('EliminarEmpleado', [id_empleado])
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al eliminar empleado: {e}")
            return False