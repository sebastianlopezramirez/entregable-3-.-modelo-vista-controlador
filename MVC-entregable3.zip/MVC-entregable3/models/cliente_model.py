#este archivo sera para el modulo clientes solo se conectara a la base de datos 
from mysql.connector import Error


class ClienteModel:
    def __init__(self, conexion):
        self.conexion = conexion

    def obtener_clientes(self):
        if self.conexion is None: return []
        try:
            cursor = self.conexion.cursor(dictionary=True)
            cursor.callproc('ObtenerClientes')
            clientes = []
            for result in cursor.stored_results():
                clientes = result.fetchall()
            cursor.close()
            return clientes
        except Error as e:
            print(f"Error al obtener clientes: {e}")
            return []

    def obtener_cliente_por_id(self, id_cliente):
        if self.conexion is None: return None
        try:
            cursor = self.conexion.cursor(dictionary=True)
            # Usamos una consulta directa para obtener un solo registro por ID
            cursor.execute(f"SELECT * FROM clientes WHERE id = {id_cliente}")
            cliente = cursor.fetchone()
            cursor.close()
            return cliente
        except Error as e:
            print(f"Error al obtener cliente por ID: {e}")
            return None

    def insertar_cliente(self, datos_cliente):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('InsertarCliente', datos_cliente)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al insertar cliente: {e}")
            return False

    def actualizar_cliente(self, datos_cliente):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('ActualizarCliente', datos_cliente)
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al actualizar cliente: {e}")
            return False

    def eliminar_cliente(self, id_cliente):
        try:
            cursor = self.conexion.cursor()
            cursor.callproc('EliminarCliente', [id_cliente])
            self.conexion.commit()
            cursor.close()
            return True
        except Error as e:
            print(f"Error al eliminar cliente: {e}")
            return False