# este archivo se encarga de la conexxion y creacion de procedimientos
import mysql.connector
from mysql.connector import Error
from tkinter import messagebox

class ProcedimientosAlmacenados:
    def __init__(self, conexion):
        self.conexion = conexion
        self.crear_procedimientos()

    def ejecutar_script(self, script):
        try:
            cursor = self.conexion.cursor()
            cursor.execute(script)
            self.conexion.commit()
            cursor.close()
        except Error as e:
            # Ignorar error si el procedimiento ya existe (código de error 1304)
            if e.errno != 1304:
                print(f"Error ejecutando script SQL: {e}")

    def crear_procedimientos(self):
        procedimientos = [
            # Clientes
            "DROP PROCEDURE IF EXISTS InsertarCliente;",
            """
            CREATE PROCEDURE InsertarCliente(
                IN p_nombre VARCHAR(100), IN p_apellido VARCHAR(100), IN p_email VARCHAR(100),
                IN p_telefono VARCHAR(20), IN p_direccion VARCHAR(200), IN p_ciudad VARCHAR(100),
                IN p_codigo_postal VARCHAR(10), IN p_pais VARCHAR(50)
            )
            BEGIN
                INSERT INTO clientes (nombre, apellido, email, telefono, direccion, ciudad, codigo_postal, pais)
                VALUES (p_nombre, p_apellido, p_email, p_telefono, p_direccion, p_ciudad, p_codigo_postal, p_pais);
            END
            """,
            "DROP PROCEDURE IF EXISTS ActualizarCliente;",
            """
            CREATE PROCEDURE ActualizarCliente(
                IN p_id INT, IN p_nombre VARCHAR(100), IN p_apellido VARCHAR(100), IN p_email VARCHAR(100),
                IN p_telefono VARCHAR(20), IN p_direccion VARCHAR(200), IN p_ciudad VARCHAR(100),
                IN p_codigo_postal VARCHAR(10), IN p_pais VARCHAR(50)
            )
            BEGIN
                UPDATE clientes SET nombre=p_nombre, apellido=p_apellido, email=p_email, telefono=p_telefono,
                direccion=p_direccion, ciudad=p_ciudad, codigo_postal=p_codigo_postal, pais=p_pais
                WHERE id = p_id;
            END
            """,
            "DROP PROCEDURE IF EXISTS EliminarCliente;",
            "CREATE PROCEDURE EliminarCliente(IN p_id INT) BEGIN DELETE FROM clientes WHERE id = p_id; END",
            "DROP PROCEDURE IF EXISTS ObtenerClientes;",
            "CREATE PROCEDURE ObtenerClientes() BEGIN SELECT * FROM clientes ORDER BY id DESC; END",

            # Productos
            "DROP PROCEDURE IF EXISTS InsertarProducto;",
            """
            CREATE PROCEDURE InsertarProducto(
                IN p_categoria_id INT, IN p_nombre VARCHAR(100), IN p_descripcion TEXT,
                IN p_precio DECIMAL(10,2), IN p_stock INT, IN p_codigo_sku VARCHAR(50), IN p_imagen VARCHAR(200)
            )
            BEGIN
                INSERT INTO productos (categoria_id, nombre, descripcion, precio, stock, codigo_sku, imagen)
                VALUES (p_categoria_id, p_nombre, p_descripcion, p_precio, p_stock, p_codigo_sku, p_imagen);
            END
            """,
            "DROP PROCEDURE IF EXISTS ActualizarProducto;",
            """
            CREATE PROCEDURE ActualizarProducto(
                IN p_id INT, IN p_categoria_id INT, IN p_nombre VARCHAR(100), IN p_descripcion TEXT,
                IN p_precio DECIMAL(10,2), IN p_stock INT, IN p_codigo_sku VARCHAR(50), IN p_imagen VARCHAR(200)
            )
            BEGIN
                UPDATE productos SET categoria_id=p_categoria_id, nombre=p_nombre, descripcion=p_descripcion,
                precio=p_precio, stock=p_stock, codigo_sku=p_codigo_sku, imagen=p_imagen
                WHERE id = p_id;
            END
            """,
            "DROP PROCEDURE IF EXISTS EliminarProducto;",
            "CREATE PROCEDURE EliminarProducto(IN p_id INT) BEGIN DELETE FROM productos WHERE id = p_id; END",
            "DROP PROCEDURE IF EXISTS ObtenerProductos;",
            "CREATE PROCEDURE ObtenerProductos() BEGIN SELECT p.id, p.nombre, p.precio, p.stock, c.nombre as categoria_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id = c.id ORDER BY p.id DESC; END",

            # Categorias
            "DROP PROCEDURE IF EXISTS InsertarCategoria;",
            """
            CREATE PROCEDURE InsertarCategoria(
                IN p_nombre VARCHAR(100), IN p_descripcion TEXT, IN p_imagen VARCHAR(200)
            )
            BEGIN
                INSERT INTO categorias (nombre, descripcion, imagen) VALUES (p_nombre, p_descripcion, p_imagen);
            END
            """,
            "DROP PROCEDURE IF EXISTS ActualizarCategoria;",
            """
            CREATE PROCEDURE ActualizarCategoria(
                IN p_id INT, IN p_nombre VARCHAR(100), IN p_descripcion TEXT, IN p_imagen VARCHAR(200)
            )
            BEGIN
                UPDATE categorias SET nombre=p_nombre, descripcion=p_descripcion, imagen=p_imagen WHERE id = p_id;
            END
            """,
            "DROP PROCEDURE IF EXISTS EliminarCategoria;",
            "CREATE PROCEDURE EliminarCategoria(IN p_id INT) BEGIN DELETE FROM categorias WHERE id = p_id; END",
            "DROP PROCEDURE IF EXISTS ObtenerCategorias;",
            "CREATE PROCEDURE ObtenerCategorias() BEGIN SELECT * FROM categorias ORDER BY id DESC; END",

            # Empleados
            "DROP PROCEDURE IF EXISTS InsertarEmpleado;",
            """
            CREATE PROCEDURE InsertarEmpleado(
                IN p_nombre VARCHAR(100), IN p_apellido VARCHAR(100), IN p_email VARCHAR(100), IN p_telefono VARCHAR(20),
                IN p_cargo VARCHAR(100), IN p_departamento VARCHAR(100), IN p_fecha_contratacion DATE, IN p_salario DECIMAL(10,2)
            )
            BEGIN
                INSERT INTO empleados (nombre, apellido, email, telefono, cargo, departamento, fecha_contratacion, salario)
                VALUES (p_nombre, p_apellido, p_email, p_telefono, p_cargo, p_departamento, p_fecha_contratacion, p_salario);
            END
            """,
            "DROP PROCEDURE IF EXISTS ActualizarEmpleado;",
            """
            CREATE PROCEDURE ActualizarEmpleado(
                IN p_id INT, IN p_nombre VARCHAR(100), IN p_apellido VARCHAR(100), IN p_email VARCHAR(100), IN p_telefono VARCHAR(20),
                IN p_cargo VARCHAR(100), IN p_departamento VARCHAR(100), IN p_fecha_contratacion DATE, IN p_salario DECIMAL(10,2)
            )
            BEGIN
                UPDATE empleados SET nombre=p_nombre, apellido=p_apellido, email=p_email, telefono=p_telefono, cargo=p_cargo,
                departamento=p_departamento, fecha_contratacion=p_fecha_contratacion, salario=p_salario
                WHERE id = p_id;
            END
            """,
            "DROP PROCEDURE IF EXISTS EliminarEmpleado;",
            "CREATE PROCEDURE EliminarEmpleado(IN p_id INT) BEGIN DELETE FROM empleados WHERE id = p_id; END",
            "DROP PROCEDURE IF EXISTS ObtenerEmpleados;",
            "CREATE PROCEDURE ObtenerEmpleados() BEGIN SELECT * FROM empleados ORDER BY id DESC; END"
        ]

        print("Creando/actualizando procedimientos almacenados...")
        for proc in procedimientos:
            self.ejecutar_script(proc)
        print("Procedimientos almacenados listos.")

def conectar_bd():
    try:
        conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='sistema_comercial'
        )
        if conexion.is_connected():
            print("Conexión exitosa a la base de datos")
            ProcedimientosAlmacenados(conexion)
            return conexion
    except Error as e:
        messagebox.showerror("Error de conexión",
                           f"No se pudo conectar a la base de datos:\n{e}\n\n"
                           "Asegúrate de que el servidor MySQL esté activo y la BD 'sistema_comercial' exista.")
        return None
